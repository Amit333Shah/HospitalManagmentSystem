---
title: Form fieldset
menu: help.docs.forms.fieldset
---

Group parts of your form to make it well-structured and clearer for users, using the ``fieldset`` element.

{% capture code %}
{% include parts/form/fieldset.html %}
{% endcapture %}
{% include example.html code=code %}